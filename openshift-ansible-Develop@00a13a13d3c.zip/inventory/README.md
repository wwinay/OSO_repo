# OpenShift Ansible inventory config files

You can install OpenShift on:

* [Amazon Web Services](aws/hosts/)
* [BYO](byo/) (Bring your own), use this inventory config file to install OpenShift on your bare metal servers
* [GCE](gce/) (Google Compute Engine)
* [libvirt](libvirt/hosts/)
* [OpenStack](openstack/hosts/)
