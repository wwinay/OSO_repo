Nuage Node
==========

Setup Nuage VRS (Virtual Routing Switching) on the Openshift Node

Requirements
------------

* Ansible 2.2
* This role assumes it has been deployed on RHEL/Fedora
