Nuage Master
============
Setup Nuage Kubernetes Monitor on the Master node


Requirements
------------

* Ansible 2.2
* This role assumes it has been deployed on RHEL/Fedora
