# Ansible profile

This is a callback plugin for timing tasks.

The upstream project lies in:
https://github.com/jlafon/ansible-profile
