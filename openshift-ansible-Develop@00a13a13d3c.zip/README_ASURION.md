# OpenShift Ansible at Asurion

This repository contains [Ansible](https://www.ansible.com/) roles and
playbooks to install, upgrade, and manage
[OpenShift](https://www.openshift.com/) clusters.


## Getting the correct version (This is from Github)

The
[master branch](https://github.com/openshift/openshift-ansible/tree/master)
tracks our current work **in development** and should be compatible
with the
[Origin master branch](https://github.com/openshift/origin/tree/master)
(code in development).

In addition to the master branch, we maintain stable branches
corresponding to upstream Origin releases, e.g.: we guarantee an
openshift-ansible 3.2 release will fully support an origin
[1.2 release](https://github.com/openshift/openshift-ansible/tree/release-1.2).
The most recent branch will often receive minor feature backports and
fixes.  Older branches will receive only critical fixes.

**Getting the right openshift-ansible release**

Follow this release pattern and you can't go wrong:

| Origin        | OpenShift-Ansible |
| ------------- | ----------------- |
| 1.3           | 3.3               |
| 1.4           | 3.4               |
| 1.*X*         | 3.*X*             |

If you're running from the openshift-ansible **master branch** we can
only guarantee compatibility with the newest origin releases **in
development**. Use a branch corresponding to your origin version if
you are not running a stable release.


## Setup (Preinstalled but good to know)

1. Requirements:
    - Ansible >= 2.2.0
    - Jinja >= 2.7
    - pyOpenSSL
    - python-lxml

    At this time these are all preinstalled on our OpenShift Compute Nodes in vRA so you don't have to worry about this part!

## Creating a new Openshift Origin cluster.
1. Build Master(s) and Node(s) in vRA uses the OpenShift Compute Node in our Catalog for this.

   Until we update our image after the install you will need to remove lvswap from all the images, it     isn't needed.

   * First disable swap for all devices:
   ```shell
   swapoff -a #Disables swap for all devices
   ```
   * Then remove the swap entry in /etc/fstab the line should be:
   ```shell
   /dev/mapper/vg_sys-swap swap                    swap    defaults        		0 0
   ```
   * Last remove the linux volume for the swap:
   ```shell
   lvremove /dev/vg_sys/swap
   ```
2. Add Masters ssh key to the Nodes and itself, If you've work sshkeys before the is pretty self explaintory.
   * From the master server you need to create a key, be sure to leave empty for no passphrase:
   ```shell
   ssh-keygen -t rsa #Bet you've seen this command before
   ```
   * Then copy this to the node servers and itself you'll be prompted for the servers root password so have that on hand from PIM.
   ```shell
   ssh-copy-id yourservername.cool.example.neat
   ```

3. Pull down the needed playbook repo for the version of origin version that that you want to install.

   * This is simply a git clone of the [repository](http://nedappjira001.int.asurion.com:8990/users/cwr.caleb.gutshall/repos/openshift-ansible/browse)

   * From here you'll need to update the host file that lives in /etc/ansible/ with the correct vaules, and [example of dev](http://nedappjira001.int.asurion.com:8990/projects/PID/repos/openshift-ansible/browse/inventory/byo/hosts.origin.example) can be found in the inventory directory for the repository.


4. You can know deploy the playbook that will install the openshift origin cluster onto the specified servers, simple run the following:
   ```shell
   ansible-playbook /openshift-ansible/browse/playbooks/byo/config.yml
   ```

# TODO
The following tasks are still manual and need to be automated:

## Node preparation
1. Register with Katello
     ```shell
     $ subscription-manager unregister
     $ subscription-manager clean
     $ yum clean all
     $ curl -O http://lprsedifkap001v.int.asurion.com/pub/bootstrap.py
     $ chmod +x bootstrap.py
     $ systemctl stop rhsmcertd.service
     $ /usr/bin/python /root/bootstrap.py -l <uname> -s lprnedifkat008v.int.asurion.com -o 'Asurion' -L 'NORTHAMERICA' -g 'RHEL7-HG' -a r17.03-RHEL7-ak-prd --force -R && wait && systemctl start rhsmcertd.service
     ```
1. Install docker
     ```shell
     $ yum install docker
    ```
2. Swap removal
     ```shell
     $ swapoff -a
     $ comment out of /etc/fstab
     $ lvremove /dev/vg_sys/swap
     ```

3. Increase /var
     ```shell
     $ lvextend -l+100%FREE /dev/vg_sys/var
     $ xfs_growfs /dev/vg_sys/var
     ```

4. enable SELinux
     ```shell
     $ vim /etc/selinux/config
            set: SELINUX=enforcing
     $ touch /.autorelabel
     $ reboot
     ```

3. Storage Nodes
     * Disable rpc services
      ```shell
            systemctl stop rpcbind.service
            systemctl disable rpcbind.service
            systemctl stop rpcbind.socket
            systemctl disable rpcbind.socket
      ```
